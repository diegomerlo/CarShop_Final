package logg;

import javax.swing.JFrame;

public class mainCarrousel {
	
	public static void main(String[]args) {
		
		
		PanelUsuario.main(1);
	}
	
}
