package logg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class AgregarVehiculo extends JFrame implements ActionListener {
    private JButton botonGuardar;
    private JTextField nombreVehiculoField, precioField, anoField, disenoField, rendimientoField, conceptoField;
    private JComboBox<String> marcaComboBox;
    private JFileChooser fileChooser;
    private File archivoSeleccionado;
    private JButton subirImagenButton;

    public AgregarVehiculo(int id_u) {
    	setTitle("Agregar Vehículo");
    	setUndecorated(true);
        setSize(443, 414);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        
        botonGuardar = new JButton("Guardar");
        botonGuardar.setBackground(Color.WHITE);
        botonGuardar.setBounds(121, 341, 192, 23);
        fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Archivos de Imagen", "jpg", "png", "jpeg", "gif"));

        nombreVehiculoField = new JTextField(20);
        nombreVehiculoField.setBounds(215, 55, 192, 23);
        precioField = new JTextField(20);
        precioField.setBounds(215, 89, 192, 23);
        anoField = new JTextField(20);
        anoField.setBounds(215, 123, 192, 23);
        disenoField = new JTextField(20);
        disenoField.setBounds(215, 198, 192, 23);
        rendimientoField = new JTextField(20);
        rendimientoField.setBounds(215, 232, 192, 23);
        conceptoField = new JTextField(20);
        conceptoField.setBounds(215, 266, 192, 23);

        String[] marcasArray = InsertarUsuarios.obtenerNombresMarcas().toArray(new String[0]);
        getContentPane().setLayout(null);
        marcaComboBox = new JComboBox<>(marcasArray);
        marcaComboBox.setBounds(215, 160, 192, 23);

        JPanel inputPanel = new JPanel();
        inputPanel.setBounds(0, 0, 430, 375);
        inputPanel.setLayout(null);
        JLabel label = new JLabel("Nombre del Vehículo:");
        label.setForeground(new Color(255, 255, 255));
        label.setBounds(56, 55, 192, 23);
        inputPanel.add(label);
        inputPanel.add(nombreVehiculoField);
        JLabel label_1 = new JLabel("Precio:");
        label_1.setForeground(new Color(255, 255, 255));
        label_1.setBounds(56, 89, 192, 23);
        inputPanel.add(label_1);
        inputPanel.add(precioField);
        JLabel label_2 = new JLabel("Año:");
        label_2.setForeground(new Color(255, 255, 255));
        label_2.setBounds(56, 123, 192, 23);
        inputPanel.add(label_2);
        inputPanel.add(anoField);
        JLabel label_3 = new JLabel("Marca:");
        label_3.setForeground(new Color(255, 255, 255));
        label_3.setBounds(56, 160, 192, 23);
        inputPanel.add(label_3);
        inputPanel.add(marcaComboBox);
        JLabel label_4 = new JLabel("Diseño:");
        label_4.setForeground(new Color(255, 255, 255));
        label_4.setBounds(56, 198, 192, 23);
        inputPanel.add(label_4);
        inputPanel.add(disenoField);
        JLabel label_5 = new JLabel("Rendimiento:");
        label_5.setForeground(new Color(255, 255, 255));
        label_5.setBounds(56, 232, 192, 23);
        inputPanel.add(label_5);
        inputPanel.add(rendimientoField);
        JLabel label_6 = new JLabel("Concepto:");
        label_6.setForeground(new Color(255, 255, 255));
        label_6.setBounds(56, 266, 192, 23);
        inputPanel.add(label_6);
        inputPanel.add(conceptoField);
        inputPanel.add(botonGuardar);
        
        
        getContentPane().add(inputPanel);
        
        subirImagenButton = new JButton("Subir Imagen");
        subirImagenButton.addActionListener(e -> {
            int seleccion = fileChooser.showOpenDialog(this);

            if (seleccion == JFileChooser.APPROVE_OPTION) {
                String rutaImagen = fileChooser.getSelectedFile().getPath();
                ImageIcon imagen = new ImageIcon(rutaImagen);
                archivoSeleccionado = fileChooser.getSelectedFile();
            }
        });
        subirImagenButton.setBackground(Color.WHITE);
        subirImagenButton.setBounds(164, 312, 119, 23);
        inputPanel.add(subirImagenButton);
        
        
        
        JButton Boton_LogoMini = new JButton("");
        Boton_LogoMini.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PanelUsuario.main(id_u);
                setVisible(false);
            }
        });
        Boton_LogoMini.setBounds(10, 8, 30, 30);

        // Configurar el botón como no opaco y sin relleno de contenido
        Boton_LogoMini.setOpaque(false);
        Boton_LogoMini.setContentAreaFilled(false);

        ImageIcon img3 = new ImageIcon("img/ATRAS.png");
        Image Scaledimg3 = img3.getImage().getScaledInstance(Boton_LogoMini.getWidth(), Boton_LogoMini.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon Scaledimg3ToIcon = new ImageIcon(Scaledimg3);
        Boton_LogoMini.setIcon(Scaledimg3ToIcon);
        inputPanel.add(Boton_LogoMini);
        
        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("IMAGEN/rectangulo.png"));
        lblNewLabel.setBounds(-35, 1, 465, 43);
        inputPanel.add(lblNewLabel);
        
        
        JLabel lblNewLabel1 = new JLabel("New label");
        lblNewLabel1.setIcon(new ImageIcon("IMAGEN/FondoT.jpg"));
        lblNewLabel1.setBounds(0, 0, 450, 405);
        inputPanel.add(lblNewLabel1);
        

        botonGuardar.addActionListener(e -> {
            if (archivoSeleccionado != null) {
                String nombreArchivo = archivoSeleccionado.getName(); // Obtenemos el nombre directamente del archivo seleccionado
                File destino = new File("img/" + nombreArchivo); // Cambia la ruta de destino según tus necesidades

                try {
                    FileInputStream fis = new FileInputStream(archivoSeleccionado);
                    FileOutputStream fos = new FileOutputStream(destino);

                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = fis.read(buffer)) > 0) {
                        fos.write(buffer, 0, length);
                    }

                    fis.close();
                    fos.close();
                    System.out.println("Imagen guardada con éxito.");

                    // Obtener los valores de los campos de texto y combo box
                    String nombreVehiculo = nombreVehiculoField.getText();
                    float precio = Float.parseFloat(precioField.getText());
                    int ano = Integer.parseInt(anoField.getText());
                    String marca = (String) marcaComboBox.getSelectedItem(); // Obtener el valor seleccionado del combo box
                    String diseno = disenoField.getText();
                    String rendimiento = rendimientoField.getText();
                    String concepto = conceptoField.getText();
                    String imagen = nombreArchivo; // Asignar el nombre del archivo guardado

                    int id_marca = InsertarUsuarios.buscarId_Vehiculo(marca);

                    InsertarUsuarios.insertarVehiculo(nombreVehiculo, precio, id_marca, ano, diseno, rendimiento, concepto, imagen);

                } catch (IOException ex) {
                    ex.printStackTrace();
                    System.err.println("Error al guardar la imagen.");
                }
            } else {
                System.err.println("Primero debe seleccionar una imagen.");
            }
        });
    }

    public static void main(int id_u) {
        SwingUtilities.invokeLater(() -> {
            AgregarVehiculo ventana = new AgregarVehiculo(id_u);
            ventana.setVisible(true);
        });
    }
    
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
    }
}
