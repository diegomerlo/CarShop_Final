package logg;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Partners{
	
	private static boolean visible=false;
    
	public Partners(int id_u) {
    	
        JFrame frame = new JFrame();
        frame.getContentPane().setEnabled(false);
        frame.setBounds(100, 100, 836, 507);
        frame.setUndecorated(true);
        frame.setPreferredSize(new Dimension(836, 507));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel Panel_Buscador = new JPanel();
    	Panel_Buscador.setBackground(new Color(112, 128, 144));
    	Panel_Buscador.setBounds(0, 0, 836, 49);
    	frame.getContentPane().add(Panel_Buscador);
    	Panel_Buscador.setLayout(null);

        Color Gris = new Color(112, 128, 144);

JButton Boton_Modelos = new JButton("Modelos");
		
		Boton_Modelos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PaginaPrincipal.main(id_u);
				frame.setVisible(false);
				
			}
			
		});
		
		Boton_Modelos.setFont(new Font("Tahoma", Font.PLAIN, 15));  //aca
		Boton_Modelos.setBounds(702,12, 89, 23);  //aca
		Boton_Modelos.setBorderPainted(false); // aca
		Boton_Modelos.setContentAreaFilled(false); //aca
		Boton_Modelos.setFocusPainted(false); //aca
		Panel_Buscador.add(Boton_Modelos);
		
		JButton Boton_MenuBarras = new JButton("");
	    Boton_MenuBarras.setBounds(10, 11, 30, 30);
		Boton_MenuBarras.setOpaque(true);
		Boton_MenuBarras.setBorderPainted(false); //aca
		Boton_MenuBarras.setContentAreaFilled(false); //aca
		Boton_MenuBarras.setFocusPainted(false); //aca
		ImageIcon img = new ImageIcon(this.getClass().getResource("/Menu1.png"));
		Boton_MenuBarras.setIcon(img);
		Panel_Buscador.add(Boton_MenuBarras);

		
    	JPanel Panel_Fondo = new JPanel();
    	
	//	Panel_Fondo.setBackground(new Color(0, 0, 0));
    	Panel_Fondo.setPreferredSize(new Dimension(836, 507));
		Panel_Fondo.setBounds(0, 49, 836, 507);
		frame.getContentPane().add(Panel_Fondo);
		Panel_Fondo.setLayout(null);
	
		/*-----------------------------------------------------*/
		
		JPanel panel = new JPanel();
		panel.setBounds(721, 0, 105, 54);
		Panel_Fondo.add(panel);
		panel.setLayout(new GridLayout(2, 2, 0, 0));
		
		panel.setVisible(visible);
		
		JButton Boton_Usuario1 = new JButton("");
		Boton_Usuario1.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {

	    		if(visible) {
	    			panel.setVisible(false);
	    			visible=false;
	    		}else {
	    			panel.setVisible(true);
	    			visible=true;
	    		}
	    	}
	    });
		Boton_Usuario1.setBounds(796, 11, 30, 30);
	    Boton_Usuario1.setBorderPainted(false);
	    Boton_Usuario1.setContentAreaFilled(false);
	    Boton_Usuario1.setFocusPainted(false);
	    
		ImageIcon img51 = new ImageIcon(this.getClass().getResource("/Usuario .png"));
		Boton_Usuario1.setIcon(img51);
		Panel_Buscador.add(Boton_Usuario1);
		
		ImageIcon logo_out = new ImageIcon("img/logout.png");
	    Image logo1 = logo_out.getImage();
	    Image scaledlogo = logo1.getScaledInstance(15, 15, Image.SCALE_SMOOTH);
	    ImageIcon scaledlogoImage = new ImageIcon(scaledlogo);
	    
	    ImageIcon logo2 = new ImageIcon("img/engranaje.png");
	    Image logoOut2 = logo2.getImage();
	    Image scaledlogo2 = logoOut2.getScaledInstance(15, 15, Image.SCALE_SMOOTH);
	    ImageIcon scaledlogoImage2 = new ImageIcon(scaledlogo2);
		
		JButton btnNewButton_1 = new JButton("Administrar");
		btnNewButton_1.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		
	    		InsertarUsuarios insertarUsuarios = new InsertarUsuarios();
	    		String nombreApellido = insertarUsuarios.obtenerNombreApellido_id(id_u); 
	    		
	    		panel.setVisible(visible);
	    		visible=false;

	    		PanelUsuario.main(id_u);
	    		frame.setVisible(false);
	    	}
	    });
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton_1.setIcon(scaledlogoImage2);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("LogOut");
		btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		
	    		InsertarUsuarios insertarUsuarios = new InsertarUsuarios();
	    		String nombreApellido = insertarUsuarios.obtenerNombreApellido_id(id_u); 
	    		
	    		JOptionPane.showMessageDialog(null, "Muchas gracias " + nombreApellido + "!!");
	    		
	    		panel.setVisible(visible);
	    		visible=false;

	    		Principal.main(null);
	    		frame.setVisible(false);
	    	}
	    });
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton.setIcon(scaledlogoImage);
		btnNewButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		panel.add(btnNewButton);
		
		/*
		JPanel Panel_Fondo = new JPanel();
	    Panel_Fondo.setBackground(Color.WHITE);
	    Panel_Fondo.setPreferredSize(new Dimension(513, 700)); // se necesita que la altura del fondo se mayor a la del jscrollpanel, para que aparezca la barra ( es decir, para que pueda mostrar algo)
	  */      
   
		JButton Boton_LogoMini = new JButton("");
		Boton_LogoMini.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {

	    		Pagina2.main(id_u);
	    		
	    		frame.setVisible(false);
	    	}
	    });
		Boton_LogoMini.setBounds(50, 11, 86, 26);
		Boton_LogoMini.setOpaque(true);
		ImageIcon img3 = new ImageIcon("img/LogoChico.png");
		Image Scaledimg3 = img3.getImage().getScaledInstance(Boton_LogoMini.getWidth(), Boton_LogoMini.getHeight(), Image.SCALE_SMOOTH);  
		ImageIcon Scaledimg3ToIcon = new ImageIcon(Scaledimg3); 
		Boton_LogoMini.setIcon(Scaledimg3ToIcon);
		Panel_Buscador.add(Boton_LogoMini);
		
		
		 JPopupMenu menuDesplegable = new JPopupMenu();
		 JMenuItem menuItem1 = new JMenuItem("Modelos");
	        menuItem1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		PaginaPrincipal.main(id_u);
	        		frame.setVisible(false);
	        	}
	        });
	        JMenuItem menuItem2 = new JMenuItem("Nuestros Autos");
	        menuItem2.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		Pagina3.main(id_u);
	        		frame.setVisible(false);
	        	}
	        });
	        JMenuItem menuItem3 = new JMenuItem("Partners");
	        menuItem3.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        	Partners.main(id_u);
	        		frame.setVisible(false);
	        	}
	        });

	        menuDesplegable.setBackground(Gris); //aca
	        menuItem1.setBackground(Gris); //aca
	        menuItem1.setForeground(Color.WHITE); //aca
	        menuItem2.setBackground(Gris); //aca
	        menuItem2.setForeground(Color.WHITE); //aca
	        menuItem3.setBackground(Gris);   //aca
	        menuItem3.setForeground(Color.WHITE); //aca
	        menuDesplegable.add(menuItem1);
	        menuDesplegable.add(menuItem2);
	        menuDesplegable.add(menuItem3);
	    /*    
	        Container s = frame8.getContentPane();
	        JScrollBar jsbHorizontal = new JScrollBar(JScrollBar.VERTICAL);
	        s.setLayout(new FlowLayout());
	        s.add(jsbHorizontal);
	        Panel_Fondo.setSize(400, 200);
	      */  
	        
	        
	        Boton_MenuBarras.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                menuDesplegable.show(Boton_MenuBarras, 0, Boton_MenuBarras.getHeight());
	            }
	        });
		
	        ModernScrollPane modernScrollPane = new ModernScrollPane(Panel_Fondo);
	        modernScrollPane.setForeground(new Color(240, 248, 255));
	        modernScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		    modernScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		    modernScrollPane.setBounds(0, 49, 836, 565);
		   
		   
		    frame.getContentPane().add(modernScrollPane);
		    
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
  
   	int j=0;
        try {
        	
            String consulta = "SELECT Nombre, Descripcion, imagenes FROM marca";
            PreparedStatement statement = cx.prepareStatement(consulta);
            ResultSet resultSet = statement.executeQuery();
            int yPosition = 28;

            while (resultSet.next()) {
            	j++;
                String nombre = resultSet.getString("Nombre");
                String descripcion = resultSet.getString("Descripcion");
                String imagenBytes = resultSet.getString("imagenes");
                

                JLabel logo = new JLabel();
                logo.setHorizontalAlignment(SwingConstants.CENTER);
                logo.setBounds(190, yPosition + 25, 116, 80);
                logo.setOpaque(false);
                ImageIcon logoImage = new ImageIcon("IMAGEN/"+imagenBytes);
                logo.setIcon(new ImageIcon(logoImage.getImage().getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH)));
                Panel_Fondo.add(logo);

                
                JLabel labelMarca = new JLabel("<html>" + nombre + "</html>");
                labelMarca.setForeground(new Color(240, 248, 255));
                labelMarca.setFont(new Font("Serif", Font.PLAIN, 50));
                labelMarca.setHorizontalAlignment(SwingConstants.CENTER);
                labelMarca.setBounds(295, yPosition - 3, 250, 130);
                Panel_Fondo.add(labelMarca);

                JLabel descripciones = new JLabel("<html>" + descripcion + "</html>");
                descripciones.setForeground(new Color(240, 248, 255));
                descripciones.setFont(new Font("Serif", Font.PLAIN, 16));
                descripciones.setHorizontalAlignment(SwingConstants.CENTER);
                descripciones.setBounds(200, yPosition + 101, 400, 130);
                Panel_Fondo.add(descripciones);
            
                JLabel cuadroTextoNombre = new JLabel();
	            cuadroTextoNombre.setHorizontalAlignment(SwingConstants.CENTER);
	            cuadroTextoNombre.setBounds(170, yPosition + 2, 480, 130);
	            cuadroTextoNombre.setOpaque(false);
	            ImageIcon cuadroNombreImage = new ImageIcon("IMAGEN/rectangulo.png");
	            cuadroTextoNombre.setIcon(new ImageIcon(cuadroNombreImage.getImage().getScaledInstance(cuadroTextoNombre.getWidth(), cuadroTextoNombre.getHeight(), Image.SCALE_SMOOTH)));
	            Panel_Fondo.add(cuadroTextoNombre);
	            
	            JLabel cuadroTextoDescripcion = new JLabel();
	            cuadroTextoDescripcion.setHorizontalAlignment(SwingConstants.CENTER);
	            cuadroTextoDescripcion.setBounds(170, yPosition + 102, 480, 130 );
	            cuadroTextoDescripcion.setOpaque(false);
	            ImageIcon cuadroDescripcionImage = new ImageIcon("IMAGEN/rectangulo.png");
	            cuadroTextoDescripcion.setIcon(new ImageIcon(cuadroDescripcionImage.getImage().getScaledInstance(cuadroTextoDescripcion.getWidth(), cuadroTextoDescripcion.getHeight(), Image.SCALE_SMOOTH)));
	            Panel_Fondo.add(cuadroTextoDescripcion);      
	            
                
                
                yPosition += 212;
            
            }
           
        	int tamano_label=507;
        
        	if(j>0) {
        		Panel_Fondo.setPreferredSize(new Dimension(836, (tamano_label*j)));
        	
        	   if(j<4) {
        		   frame.setPreferredSize(new Dimension(836,(tamano_label)));
        	   }
        	   else
        	   {
        		   frame.setPreferredSize(new Dimension(836,507)); 
        	   }
        	}
            // Cerrar recursos
            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Partners.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            // Desconectar la base de datos al finalizar.
            conexion.desconectar();
        }
        
        if(j==0) {
        	  JLabel labelSinMarca = new JLabel("<html>No se registro ninguna marca hasta el momento...</html>");
             labelSinMarca.setForeground(new Color(255, 255, 255));
             labelSinMarca.setFont(new Font("Serif", Font.CENTER_BASELINE, 16));
             labelSinMarca.setHorizontalAlignment(SwingConstants.CENTER);
             labelSinMarca.setBounds(80,10, 350, 210);
             Panel_Fondo.add(labelSinMarca);
              
             Panel_Fondo.setPreferredSize(new Dimension(836, 507));
             frame.setPreferredSize(new Dimension(836,507));
       	   


        }

        JLabel labelFondo = new JLabel();
        labelFondo.setHorizontalAlignment(SwingConstants.CENTER);
       if(j==0) {
        labelFondo.setBounds(0, 0, 836,507);
       }
       else {
       labelFondo.setBounds(0, 0, 836,(507*j)+32);
       }
       labelFondo.setOpaque(true);
        ImageIcon imgFondo = new ImageIcon("IMAGEN/FondoT.png");
        Image scaledImage = imgFondo.getImage().getScaledInstance(labelFondo.getWidth(), labelFondo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        labelFondo.setIcon(scaledIcon);
        Panel_Fondo.add(labelFondo);

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(int id_u) {
        SwingUtilities.invokeLater(() -> new Partners(id_u));
    }
}
