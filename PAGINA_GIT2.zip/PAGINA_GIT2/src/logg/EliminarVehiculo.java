package logg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EliminarVehiculo extends JFrame implements ActionListener {
    private JButton eliminarButton;
    private JComboBox<String> vehiculoComboBox;
    
    public EliminarVehiculo(int id_u) {
        setTitle("Eliminar Vehículo");
        setBounds(10, 10, 390, 340);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel nombreVehiculoLabel = new JLabel("Nombre del vehículo");
        nombreVehiculoLabel.setFont(new Font("Times New Roman", Font.PLAIN, 17));
        nombreVehiculoLabel.setBounds(124, 11, 200, 187);
        nombreVehiculoLabel.setForeground(Color.WHITE);

        eliminarButton = new JButton("Eliminar");
        eliminarButton.setBackground(new Color(255, 255, 255));
        eliminarButton.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        eliminarButton.setBounds(152, 247, 108, 25);

        panel.add(nombreVehiculoLabel);
        panel.add(eliminarButton);

        vehiculoComboBox = new JComboBox<>();
        vehiculoComboBox.setBounds(96, 146, 209, 38);
        panel.add(vehiculoComboBox);

        JButton Boton_LogoMini = new JButton("");
        Boton_LogoMini.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PanelUsuario.main(id_u);
                setVisible(false);
            }
        });
        Boton_LogoMini.setBounds(10, 8, 30, 30);

        // Configurar el botón como no opaco y sin relleno de contenido
        Boton_LogoMini.setOpaque(false);
        Boton_LogoMini.setContentAreaFilled(false);

        ImageIcon img3 = new ImageIcon("img/ATRAS.png");
        Image Scaledimg3 = img3.getImage().getScaledInstance(Boton_LogoMini.getWidth(), Boton_LogoMini.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon Scaledimg3ToIcon = new ImageIcon(Scaledimg3);
        Boton_LogoMini.setIcon(Scaledimg3ToIcon);
        panel.add(Boton_LogoMini);

        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("IMAGEN/rectangulo.png"));
        lblNewLabel.setBounds(-21, 0, 421, 43);
        panel.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("New label");
        lblNewLabel_1.setIcon(new ImageIcon("IMAGEN/FondoT.png"));
        lblNewLabel_1.setBounds(0, 43, 400, 304);
        panel.add(lblNewLabel_1);

        eliminarButton.addActionListener(this);

        getContentPane().add(panel, BorderLayout.CENTER);

        // Cargar los nombres de los vehículos en el ComboBox
        cargarNombresVehiculos();
    }

    // Método para cargar los nombres de los vehículos desde la base de datos
    private void cargarNombresVehiculos() {
        try {
            // Establecer la conexión a tu base de datos
            Conexion conexion = new Conexion();
            Connection connection = conexion.conectar();

            // Consulta SQL para obtener los nombres de los vehículos
            String consulta = "SELECT nombre FROM vehiculos";
            PreparedStatement statement = connection.prepareStatement(consulta);
            ResultSet resultSet = statement.executeQuery();

            // Llenar el ComboBox con los nombres de los vehículos
            ArrayList<String> nombres = new ArrayList<>();
            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                nombres.add(nombre);
            }

            // Cerrar recursos
            resultSet.close();
            statement.close();
            connection.close();

            // Actualizar el ComboBox con los nombres de los vehículos
            vehiculoComboBox.setModel(new DefaultComboBoxModel<>(nombres.toArray(new String[0])));
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los nombres de los vehículos: " + ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == eliminarButton) {
            String nombreSeleccionado = (String) vehiculoComboBox.getSelectedItem();

            if (nombreSeleccionado != null && !nombreSeleccionado.isEmpty()) {
                try {
                    // Establecer la conexión a tu base de datos
                    Conexion conexion = new Conexion();
                    Connection connection = conexion.conectar();

                    // Consulta SQL para eliminar un vehículo por su nombre
                    String consulta = "DELETE FROM vehiculos WHERE nombre = ?";
                    PreparedStatement statement = connection.prepareStatement(consulta);
                    statement.setString(1, nombreSeleccionado);

                    // Ejecutar la consulta de eliminación
                    int filasAfectadas = statement.executeUpdate();

                    if (filasAfectadas > 0) {
                        JOptionPane.showMessageDialog(this, "Vehículo eliminado correctamente.");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró ningún vehículo con ese nombre.");
                    }

                    // Cerrar recursos
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al eliminar el vehículo: " + ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un vehículo válido.");
            }
        }
    }

    public static void main(int id_u) {
        SwingUtilities.invokeLater(() -> {
            EliminarVehiculo ventana = new EliminarVehiculo(id_u);
            ventana.setVisible(true);
        });
    }
}
