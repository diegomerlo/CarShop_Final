/*package logg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class op3Prueba{

    public op3Prueba() {
    	
        JFrame frame = new JFrame();
        frame.setBounds(300, 0, 529, 900);
        frame.setPreferredSize(new Dimension(529, 220));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel panelBuscador = new JPanel();
        panelBuscador.setBackground(new Color(112, 128, 144));
        panelBuscador.setBounds(0, 0, 513, 49);
        frame.getContentPane().add(panelBuscador);
        panelBuscador.setLayout(null);

        Color gris = new Color(112, 128, 144);

        JButton botonUsuario = new JButton("");
        botonUsuario.setBounds(473, 11, 30, 30);
        botonUsuario.setBorderPainted(false);
        botonUsuario.setContentAreaFilled(false);
        botonUsuario.setFocusPainted(false);
        ImageIcon imgUsuario = new ImageIcon(this.getClass().getResource("/Usuario .png"));
        botonUsuario.setIcon(imgUsuario);
        panelBuscador.add(botonUsuario);

        JButton botonModelos = new JButton("Modelos");
        botonModelos.setFont(new Font("Tahoma", Font.PLAIN, 15));
        botonModelos.setBounds(379, 12, 89, 23);
        botonModelos.setBorderPainted(false);
        botonModelos.setContentAreaFilled(false);
        botonModelos.setFocusPainted(false);
        panelBuscador.add(botonModelos);

        JButton botonMenuBarras = new JButton("");
        botonMenuBarras.setBounds(10, 11, 30, 30);
        botonMenuBarras.setOpaque(true);
        botonMenuBarras.setBorderPainted(false);
        botonMenuBarras.setContentAreaFilled(false);
        botonMenuBarras.setFocusPainted(false);
        ImageIcon imgMenu = new ImageIcon(this.getClass().getResource("/Menu1.png"));
        botonMenuBarras.setIcon(imgMenu);
        panelBuscador.add(botonMenuBarras);

        JPanel panelFondo = new JPanel();
        panelFondo.setPreferredSize(new Dimension(513, 880));
        panelFondo.setBounds(0, 49, 513, 293);
        frame.getContentPane().add(panelFondo);
        panelFondo.setLayout(null);

        JPopupMenu menuDesplegable = new JPopupMenu();
        JMenuItem menuItem1 = new JMenuItem("Opción 1");
        JMenuItem menuItem2 = new JMenuItem("Opción 2");
        JMenuItem menuItem3 = new JMenuItem("Opción 3");

        menuDesplegable.setBackground(gris);
        menuItem1.setBackground(gris);
        menuItem1.setForeground(Color.WHITE);
        menuItem2.setBackground(gris);
        menuItem2.setForeground(Color.WHITE);
        menuItem3.setBackground(gris);
        menuItem3.setForeground(Color.WHITE);
        menuDesplegable.add(menuItem1);
        menuDesplegable.add(menuItem2);
        menuDesplegable.add(menuItem3);

        botonMenuBarras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuDesplegable.show(botonMenuBarras, 0, botonMenuBarras.getHeight());
            }
        });

        ModernScrollPane modernScrollPane = new ModernScrollPane(panelFondo);
        modernScrollPane.setForeground(new Color(240, 248, 255));
        modernScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        modernScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        modernScrollPane.setBounds(0, 49, 513, 565);

        frame.add(modernScrollPane);
    	JPanel Panel_Fondo = new JPanel();
    	
    	//	Panel_Fondo.setBackground(new Color(0, 0, 0));
        	Panel_Fondo.setPreferredSize(new Dimension(513, 900));
    		Panel_Fondo.setBounds(0, 49, 513, 293);
    		frame.getContentPane().add(Panel_Fondo);
    		Panel_Fondo.setLayout(null);
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
  
   	int j=0;
        try {
        	//Para el ciclo for
        	
        	
        
            // Consulta SQL para obtener las marcas
            String consulta = "SELECT Nombre, Descripcion, imagenes FROM marca";
            PreparedStatement statement = cx.prepareStatement(consulta);
            ResultSet resultSet = statement.executeQuery();
            int yPosition = 28;

            while (resultSet.next()) {
            	j++;
                String nombre = resultSet.getString("Nombre");
                String descripcion = resultSet.getString("Descripcion");
                String imagenBytes = resultSet.getString("imagenes");
                

                JLabel logo = new JLabel();
                logo.setHorizontalAlignment(SwingConstants.CENTER);
                logo.setBounds(40, yPosition + 25, 116, 80);
                logo.setOpaque(false);
                ImageIcon logoImage = new ImageIcon("IMAGEN/"+imagenBytes);
                logo.setIcon(new ImageIcon(logoImage.getImage().getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH)));
                panelFondo.add(logo);

                
                JLabel labelMarca = new JLabel("<html>" + nombre + "</html>");
                labelMarca.setForeground(new Color(240, 248, 255));
                labelMarca.setFont(new Font("Serif", Font.PLAIN, 50));
                labelMarca.setHorizontalAlignment(SwingConstants.CENTER);
                labelMarca.setBounds(145, yPosition - 3, 250, 130);
                panelFondo.add(labelMarca);

                JLabel descripciones = new JLabel("<html>" + descripcion + "</html>");
                descripciones.setForeground(new Color(240, 248, 255));
                descripciones.setFont(new Font("Serif", Font.PLAIN, 16));
                descripciones.setHorizontalAlignment(SwingConstants.CENTER);
                descripciones.setBounds(50, yPosition + 101, 400, 130);
                panelFondo.add(descripciones);
            
                JLabel cuadroTextoNombre = new JLabel();
	            cuadroTextoNombre.setHorizontalAlignment(SwingConstants.CENTER);
	            cuadroTextoNombre.setBounds(20, yPosition + 2, 480, 130);
	            cuadroTextoNombre.setOpaque(false);
	            ImageIcon cuadroNombreImage = new ImageIcon("IMAGEN/rectangulo.png");
	            cuadroTextoNombre.setIcon(new ImageIcon(cuadroNombreImage.getImage().getScaledInstance(cuadroTextoNombre.getWidth(), cuadroTextoNombre.getHeight(), Image.SCALE_SMOOTH)));
	            Panel_Fondo.add(cuadroTextoNombre);
	            
	            JLabel cuadroTextoDescripcion = new JLabel();
	            cuadroTextoDescripcion.setHorizontalAlignment(SwingConstants.CENTER);
	            cuadroTextoDescripcion.setBounds(20, yPosition + 102, 480, 130 );
	            cuadroTextoDescripcion.setOpaque(false);
	            ImageIcon cuadroDescripcionImage = new ImageIcon("IMAGEN/rectangulo.png");
	            cuadroTextoDescripcion.setIcon(new ImageIcon(cuadroDescripcionImage.getImage().getScaledInstance(cuadroTextoDescripcion.getWidth(), cuadroTextoDescripcion.getHeight(), Image.SCALE_SMOOTH)));
	            Panel_Fondo.add(cuadroTextoDescripcion);      
	            
                
                
                yPosition += 212;
            
            }
           
        	int tamano_label=220;
        
        	if(j>0) {
        	   panelFondo.setPreferredSize(new Dimension(513, (tamano_label*j)));
        	
        	   if(j<4) {
        		   frame.setPreferredSize(new Dimension(529,(tamano_label*j)+120));
        	   }
        	   else
        	   {
        		   frame.setPreferredSize(new Dimension(529,653)); 
        	   }
        	}
            // Cerrar recursos
            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(op3Prueba.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            // Desconectar la base de datos al finalizar.
            conexion.desconectar();
        }
        
        if(j==0) {
        	  JLabel labelSinMarca = new JLabel("<html>No se registro ninguna marca hasta el momento...</html>");
             labelSinMarca.setForeground(new Color(255, 255, 255));
             labelSinMarca.setFont(new Font("Serif", Font.CENTER_BASELINE, 16));
             labelSinMarca.setHorizontalAlignment(SwingConstants.CENTER);
             labelSinMarca.setBounds(80,10, 350, 210);
             panelFondo.add(labelSinMarca);
              
             panelFondo.setPreferredSize(new Dimension(513, 410));
             frame.setPreferredSize(new Dimension(529,306));
       	   


        }

        JLabel labelFondo = new JLabel();
        labelFondo.setHorizontalAlignment(SwingConstants.CENTER);
       if(j==0) {
        labelFondo.setBounds(0, 0, 513,220);
       }
       else {
       labelFondo.setBounds(0, 0, 513,(220*j)+32);
       }
       labelFondo.setOpaque(true);
        ImageIcon imgFondo = new ImageIcon("IMAGEN/FondoT.png");
        Image scaledImage = imgFondo.getImage().getScaledInstance(labelFondo.getWidth(), labelFondo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        labelFondo.setIcon(scaledIcon);
        panelFondo.add(labelFondo);

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new op3Prueba());
    }
}*/