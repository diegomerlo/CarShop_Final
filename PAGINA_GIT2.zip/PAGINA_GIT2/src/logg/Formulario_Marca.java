package logg;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Formulario_Marca extends JFrame implements ActionListener {
    private JTextField nombreMarcaField, informacionField;
    private JButton agregarMarcaButton, subirImagenButton;
    private JLabel nombreMarcaLabel, informacionLabel;
    private File archivoSeleccionado;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/CarShop2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private JFileChooser fileChooser = new JFileChooser(); // Declarar e inicializar el JFileChooser
    private JLabel imagenLabel = new JLabel("Imagen: "); // Declarar e inicializar el JLabel
    private JLabel lblNewLabel;

    public Formulario_Marca(int id_u) {
        setTitle("Agregar Nueva Marca");
        setBounds(10,10,390, 340);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a background label and set the image as its icon
        JLabel background = new JLabel(new ImageIcon("IMAGEN/FondoT.jpg"));
        setContentPane(background);
        background.setLayout(new BoxLayout(background, BoxLayout.Y_AXIS)); // Cambio a BoxLayout vertical
        
        

        // Create the UI components
        JPanel inputPanel = new JPanel();
        inputPanel.setAlignmentY(Component.TOP_ALIGNMENT);
        inputPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        inputPanel.setOpaque(false);
        inputPanel.setLayout(null);


     // Nombre de la Marca
        nombreMarcaLabel = new JLabel("Nombre de la Marca:");
        nombreMarcaLabel.setBounds(137, 69, 143, 14);
        nombreMarcaLabel.setForeground(new Color(255, 255, 255));
        inputPanel.add(nombreMarcaLabel);
        nombreMarcaField = new JTextField(20);
        nombreMarcaField.setBounds(114, 88, 166, 20);
        inputPanel.add(nombreMarcaField);
        informacionLabel = new JLabel("Información de la Marca:");
        informacionLabel.setBounds(134, 119, 143, 14);
        informacionLabel.setForeground(new Color(255, 255, 255));
        inputPanel.add(informacionLabel);
        informacionField = new JTextField(20);
        informacionField.setBounds(94, 138, 205, 38);
        inputPanel.add(informacionField);
        Component verticalStrut = Box.createVerticalStrut(10);
        verticalStrut.setBounds(0, 0, 0, 0);
        inputPanel.add(verticalStrut);
        background.add(inputPanel);
                        agregarMarcaButton = new JButton("Guardar");
                        agregarMarcaButton.setBackground(new Color(255, 255, 255));
                        agregarMarcaButton.setBounds(137, 231, 119, 23);
                        agregarMarcaButton.addActionListener(this);
                                subirImagenButton = new JButton("Subir Imagen");
                                subirImagenButton.setBackground(new Color(255, 255, 255));
                                subirImagenButton.setBounds(137, 197, 119, 23);
                                subirImagenButton.addActionListener(this);
                                inputPanel.add(subirImagenButton);
                        inputPanel.add(agregarMarcaButton);
                        
                      
                        
                        JButton Boton_LogoMini = new JButton("");
                        Boton_LogoMini.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                PanelUsuario.main(id_u);
                                setVisible(false);
                            }
                        });
                        Boton_LogoMini.setBounds(10, 8, 30, 30);

                        // Configurar el botón como no opaco y sin relleno de contenido
                        Boton_LogoMini.setOpaque(false);
                        Boton_LogoMini.setContentAreaFilled(false);

                        ImageIcon img3 = new ImageIcon("img/ATRAS.png");
                        Image Scaledimg3 = img3.getImage().getScaledInstance(Boton_LogoMini.getWidth(), Boton_LogoMini.getHeight(), Image.SCALE_SMOOTH);
                        ImageIcon Scaledimg3ToIcon = new ImageIcon(Scaledimg3);
                        Boton_LogoMini.setIcon(Scaledimg3ToIcon);
                        inputPanel.add(Boton_LogoMini);
                        
                        lblNewLabel = new JLabel("New label");
                        lblNewLabel.setIcon(new ImageIcon("IMAGEN/rectangulo.png"));
                        lblNewLabel.setBounds(-21, 0, 421, 43);
                        inputPanel.add(lblNewLabel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == agregarMarcaButton) {
            String nombreMarca = nombreMarcaField.getText().trim();
            String informacion = informacionField.getText().trim();

            if (!nombreMarca.isEmpty()) {
                if (archivoSeleccionado != null) {
                    String nombreImagen = archivoSeleccionado.getName(); // Obtener el nombre de la imagen automáticamente

                    // Copiar la imagen a la carpeta "img_empresas" con el nombre de la imagen
                    try {
                        FileInputStream fis = new FileInputStream(archivoSeleccionado);
                        FileOutputStream fos = new FileOutputStream("IMAGEN/" + nombreImagen);

                        byte[] buffer = new byte[1024];
                        int length;
                        while ((length = fis.read(buffer)) > 0) {
                            fos.write(buffer, 0, length);
                        }

                        fis.close();
                        fos.close();
                        System.out.println("Imagen guardada en img_empresas: " + nombreImagen);

                        // Insertar la nueva marca en la base de datos (usando la información y nombre de imagen)
                        Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                        String insertSQL = "INSERT INTO marca (Nombre, Descripcion, imagenes) VALUES (?, ?, ?)";
                        PreparedStatement preparedStatement = connection.prepareStatement(insertSQL);
                        preparedStatement.setString(1, nombreMarca);
                        preparedStatement.setString(2, informacion);
                        preparedStatement.setString(3, nombreImagen); // Almacenar el nombre de la imagen, no los datos binarios

                        // Execute the INSERT statement
                        int rowsInserted = preparedStatement.executeUpdate();

                        if (rowsInserted > 0) {
                            JOptionPane.showMessageDialog(this, "Marca agregada correctamente.");
                        } else {
                            JOptionPane.showMessageDialog(this, "No se pudo agregar la marca.");
                        }

                        // Close the database connection and statement
                        preparedStatement.close();
                        connection.close();

                    } catch (SQLException | IOException ex) {
                        ex.printStackTrace();
                        // Manejar la excepción de conexión aquí sin mostrar un mensaje de error al usuario
                        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Seleccione una imagen.");
                }

                nombreMarcaField.setText("");
                informacionField.setText("");
                archivoSeleccionado = null; // Restablecer el archivo seleccionado
            } else {
                JOptionPane.showMessageDialog(this, "Ingrese el nombre de la nueva marca.");
            }
        } else if (e.getSource() == subirImagenButton) {
            int seleccion = fileChooser.showOpenDialog(this);

            if (seleccion == JFileChooser.APPROVE_OPTION) {
                String rutaImagen = fileChooser.getSelectedFile().getPath();
                ImageIcon imagen = new ImageIcon(rutaImagen);
                imagenLabel.setIcon(imagen);
                archivoSeleccionado = fileChooser.getSelectedFile();
            }
        }
    }

    public static void main(int id_u) {
        SwingUtilities.invokeLater(() -> {
            Formulario_Marca ventana = new Formulario_Marca(id_u);
            ventana.setVisible(true);
        });
    }
}
