package logg;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BorrarDatosNBD extends JFrame implements ActionListener {
    private JButton borrarButton;
    private JComboBox<String> marcaComboBox; // Cambiado a JComboBox<String>
    private JComboBox<String> archivoComboBox;
    public BorrarDatosNBD(int id_u) {
        setTitle("Borrar de la Base de Datos");
        setBounds(10,10,390, 340);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();

        JLabel nombreEmpresaLabel = new JLabel("Nombre de la empresa");
        nombreEmpresaLabel.setFont(new Font("Times New Roman", Font.PLAIN, 17));
        nombreEmpresaLabel.setBounds(124, 11, 200, 187);
        nombreEmpresaLabel.setForeground(Color.WHITE);

        JLabel nombreArchivoLabel = new JLabel("Nombre del archivo a borrar:");
        nombreArchivoLabel.setForeground(Color.WHITE);

        borrarButton = new JButton("Borrar");
        borrarButton.setBackground(new Color(255, 255, 255));
        borrarButton.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        borrarButton.setBounds(152, 247, 108, 25);
        panel.setLayout(null);

        panel.add(nombreEmpresaLabel);
        panel.add(nombreArchivoLabel);

        marcaComboBox = new JComboBox<>(); // Cambiado a JComboBox<String>
        marcaComboBox.setBounds(96, 146, 209, 38);
        panel.add(marcaComboBox); // Cambiado a marcaComboBox

        
        archivoComboBox = new JComboBox<>(); // Cambiado a JComboBox<String>
        archivoComboBox.setBounds(96, 146, 209, 38);
        panel.add(archivoComboBox);
        
        JLabel label = new JLabel();
        label.setBounds(322, 75, 161, 187);
        panel.add(label);
        panel.add(borrarButton);

        borrarButton.addActionListener(this);

        getContentPane().add(panel, BorderLayout.CENTER);
        
        JButton Boton_LogoMini = new JButton("");
        Boton_LogoMini.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PanelUsuario.main(id_u);
                setVisible(false);
            }
        });
        Boton_LogoMini.setBounds(10, 8, 30, 30);

        // Configurar el botón como no opaco y sin relleno de contenido
        Boton_LogoMini.setOpaque(false);
        Boton_LogoMini.setContentAreaFilled(false);

        ImageIcon img3 = new ImageIcon("img/ATRAS.png");
        Image Scaledimg3 = img3.getImage().getScaledInstance(Boton_LogoMini.getWidth(), Boton_LogoMini.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon Scaledimg3ToIcon = new ImageIcon(Scaledimg3);
        Boton_LogoMini.setIcon(Scaledimg3ToIcon);
        panel.add(Boton_LogoMini);

        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("IMAGEN/rectangulo.png"));
        lblNewLabel.setBounds(-21, 0, 421, 43);
        panel.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("New label");
        lblNewLabel_1.setIcon(new ImageIcon("IMAGEN/FondoT.png"));
        lblNewLabel_1.setBounds(0, 43, 400, 304);
        panel.add(lblNewLabel_1);

        // Cargar los nombres de las marcas en el ComboBox
        cargarNombresMarcas();
    }

    // Método para cargar los nombres de las marcas desde la base de datos
    private void cargarNombresMarcas() {
        try {
            // Establecer la conexión a tu base de datos
            Conexion conexion = new Conexion();
            Connection connection = conexion.conectar();

            // Consulta SQL para obtener los nombres de las marcas
            String consulta = "SELECT nombre FROM marca";
            PreparedStatement statement = connection.prepareStatement(consulta);
            ResultSet resultSet = statement.executeQuery();

            // Llenar el ComboBox con los nombres de las marcas
            ArrayList<String> nombres = new ArrayList<>();
            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                nombres.add(nombre);
            }

            // Cerrar recursos
            resultSet.close();
            statement.close();
            connection.close();

            // Actualizar el ComboBox con los nombres de las marcas
            marcaComboBox.setModel(new DefaultComboBoxModel<>(nombres.toArray(new String[0])));
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los nombres de las marcas: " + ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == borrarButton) {
            String nombreSeleccionado = (String) marcaComboBox.getSelectedItem(); // Cambiado a marcaComboBox
            File archivoSeleccionado = (File) archivoComboBox.getSelectedItem();

            if (nombreSeleccionado != null && !nombreSeleccionado.isEmpty()) {
                try {
                    // Establecer la conexión a tu base de datos
                    Conexion conexion = new Conexion();
                    Connection connection = conexion.conectar();

                    // Consulta SQL para eliminar un registro por su nombre de empresa
                    String consulta = "DELETE FROM marca WHERE nombre = ?";
                    PreparedStatement statement = connection.prepareStatement(consulta);
                    statement.setString(1, nombreSeleccionado);

                    // Ejecutar la consulta de eliminación
                    int filasAfectadas = statement.executeUpdate();

                    if (filasAfectadas > 0) {
                        JOptionPane.showMessageDialog(this, "Registro de marca eliminado correctamente.");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró ningún registro de marca con ese nombre.");
                    }

                    // Cerrar recursos
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al eliminar el registro de marca: " + ex.getMessage());
                }
            } else if (archivoSeleccionado != null) {
                // Aquí puedes agregar lógica para eliminar el archivo seleccionado
                // Puedes usar el objeto File "archivoSeleccionado" para acceder al archivo y eliminarlo
                if (archivoSeleccionado.delete()) {
                    JOptionPane.showMessageDialog(this, "Archivo eliminado correctamente.");
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo eliminar el archivo.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un nombre de empresa o archivo válido.");
            }
        }
    }

    public static void main(int id_u) {
        SwingUtilities.invokeLater(() -> {
            BorrarDatosNBD ventana = new BorrarDatosNBD(id_u);
            ventana.setVisible(true);
        });
    }
}

