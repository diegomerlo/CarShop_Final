package logg;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;




public class Chart extends Application {

    public static PieChart createPieChart() {
        // Crear un PieChart
    	
        int cantidadlikestotales=0;
        int cantidadAutos = InsertarUsuarios.ObtenerCantidadAutos();

        

        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();

        for(int i = 1; i <= cantidadAutos; i++) {
        	int cantidadlikes = InsertarUsuarios.obtenerCantidadLikes(i);

        	cantidadlikestotales = cantidadlikestotales + cantidadlikes;

        }


        for (int i = 1; i <= cantidadAutos; i++) {

        	String nombreautos = InsertarUsuarios.obtenerNombreAuto(i);

        	int cantidadlikes = InsertarUsuarios.obtenerCantidadLikes(i);

        	data.add(new PieChart.Data(nombreautos, ((float) cantidadlikes / cantidadlikestotales) * 100));


        }

       PieChart pieChart = new PieChart(data);       
        
        
        return pieChart;
    }

    @Override
    public void start(Stage primaryStage) {
    	
        PieChart pieChart = createPieChart();

        // Crear un StackPane para el PieChart
        StackPane pieChartPane = new StackPane(pieChart);

        // Crear una escena de JavaFX
        Scene scene = new Scene(pieChartPane, 400, 400);
  
        
        
        
        
        // Configurar el escenario y mostrarlo
        primaryStage.setTitle("JavaFX PieChart");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
  
    
}
