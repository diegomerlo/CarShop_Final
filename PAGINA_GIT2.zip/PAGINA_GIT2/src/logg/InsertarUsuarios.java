package logg;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.ResultSet;
import java.util.Date;

public class InsertarUsuarios {
    public static void insertarUsuario(String gmail, String contrasena, String nombre, String apellido1) {
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                int id = 0;
                String apellido2 = null;
                String apellido3 = null;
                
                String query = "INSERT INTO Usuarios (ID_U, Gmail, Contraseña, Nombre, Apellido1, Apellido2, Apellido3) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setInt(1, id);
                statement.setString(2, gmail);
                statement.setString(3, contrasena);
                statement.setString(4, nombre);
                statement.setString(5, apellido1);
                statement.setString(6, apellido2);
                statement.setString(7, apellido3);
                
                int filasInsertadas = statement.executeUpdate();
                if (filasInsertadas > 0) {
                    System.out.println("Datos insertados exitosamente.");
                } else {
                    System.out.println("No se pudieron insertar los datos.");
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static boolean verificarCredenciales(String gmail, String contrasena) {
    	Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT COUNT(*) FROM Usuarios WHERE Gmail = ? AND Contraseña = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setString(1, gmail);
                statement.setString(2, contrasena);
                
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0; // Si hay al menos un registro con esas credenciales, retorna true
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return false;
    }
    
    public String obtenerNombreApellido(String gmail) {
        String nombreApellido = null;
        
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT Nombre FROM Usuarios WHERE Gmail = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setString(1, gmail);
                
                ResultSet resultSet = statement.executeQuery();
                
                if (resultSet.next()) {
                    nombreApellido = resultSet.getString("Nombre");
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return nombreApellido;
    }
    
    public static String obtenerNombre(int id_u) {
    	
        String nombreApellido = null;
        
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT CONCAT(Nombre,' ',Apellido1) AS Nombre FROM Usuarios WHERE ID_U = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setInt(1, id_u);
                
                ResultSet resultSet = statement.executeQuery();
                
                if (resultSet.next()) {
                    nombreApellido = resultSet.getString("Nombre");
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return nombreApellido;
    }
    
    public static String obtenergmail(int id_u) {
    	
        String gmail = null;
        
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT Gmail FROM Usuarios WHERE ID_U = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setInt(1, id_u);
                
                ResultSet resultSet = statement.executeQuery();
                
                if (resultSet.next()) {
                    gmail = resultSet.getString("Gmail");
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return gmail;
    }
    
    public String obtenerNombreApellido_id(int id_u) {
        String nombreApellido = null;
        
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT Nombre FROM Usuarios WHERE ID_U = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setInt(1, id_u);
                
                ResultSet resultSet = statement.executeQuery();
                
                if (resultSet.next()) {
                    nombreApellido = resultSet.getString("Nombre");
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return nombreApellido;
    }
    
    public int obtenerID(String gmail) {
        int id = 0 ;
        
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT ID_U FROM Usuarios WHERE Gmail = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setString(1, gmail);
                
                ResultSet resultSet = statement.executeQuery();
                
                if (resultSet.next()) {
                    id = resultSet.getInt("ID_U");
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return id;
    }
    
    public static List<String> obtenerRegistros(int usuarioId) {
        List<String> registros = new ArrayList<>();
        
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT v.Nombre, COUNT(*) FROM registros INNER JOIN vehiculos v ON registros.Vehiculo = v.ID_V WHERE Usuario = ? GROUP BY Vehiculo;";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setInt(1, usuarioId);
                
                ResultSet resultSet = statement.executeQuery();
                
                while (resultSet.next()) {
                    String vehiculo = resultSet.getString("Nombre");
                    int count = resultSet.getInt(2); // La columna se obtiene por número de índice (1, 2, 3, etc.)
                    
                    String resultado = "" + vehiculo + ": " + count;
                    registros.add(resultado);
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return registros;
    }
    
    public static void insertarRegistro(int id_u, int idVehiculo) {
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();

        if (cx != null) {
            try {
            	
                int ID_R=0;
                int Usuario=id_u;
               
             

                String query = "INSERT INTO Registros (ID_R, Usuario, Vehiculo) VALUES (?, ?, ?)";
                PreparedStatement statement = cx.prepareStatement(query);
                
                statement.setInt(1, ID_R);
                statement.setInt(2, Usuario);
                statement.setInt(3, idVehiculo);
                
              
                int filasInsertadas = statement.executeUpdate();
                if (filasInsertadas > 0) {
                    System.out.println("Registro insertado exitosamente.");
                } else {
                    System.out.println("No se pudo insertar el registro.");
                }

                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    
    public static int obtenerCantidadLikes(int idVehiculo) {
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        int cantidadLikes = 0;

        if (cx != null) {
            try {
                String query = "SELECT COUNT(*) FROM Registros WHERE Vehiculo = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setInt(1, idVehiculo);
                
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    cantidadLikes = resultSet.getInt(1);
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return cantidadLikes;
    }
    
    public static boolean verificarExistenciaGmail(String gmail) {//diego
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT COUNT(*) FROM Usuarios WHERE Gmail = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setString(1, gmail);
                
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0; // Si hay al menos un registro con ese correo, retorna true
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return false;
    }

    public static int ObtenerCantidadAutos() {//Agus
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        int Cantidadautos = 0;

        if (cx != null) {
            try {
                String query = "SELECT COUNT(*) FROM vehiculos ";
                PreparedStatement statement = cx.prepareStatement(query);
              
                
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                	Cantidadautos = resultSet.getInt(1);
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return Cantidadautos;
    }
    
    public static String obtenerNombreAuto(int ID_V) {//agus
        String nombreauto = null;
        
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        if (cx != null) {
            try {
                String query = "SELECT Nombre FROM vehiculos where ID_V = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setInt(1,ID_V);
                
                ResultSet resultSet = statement.executeQuery();
                
                if (resultSet.next()) {
                	nombreauto = resultSet.getString("Nombre");
                }
                
                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return nombreauto;
    }
    /*-------------------------------------------------------------------------*/
    
    public static List<String[]> obtenerInformacionVehiculos() {
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        List<String[]> informacionVehiculos = new ArrayList<>();

        if (cx != null) {
            try {
                String query = "SELECT Diseno, Rendimiento, Concepto FROM Vehiculos";
                PreparedStatement statement = cx.prepareStatement(query);
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    String diseno = resultSet.getString("Diseno");
                    String rendimiento = resultSet.getString("Rendimiento");
                    String concepto = resultSet.getString("Concepto");

                    String[] texto = {diseno, rendimiento, concepto};
                    informacionVehiculos.add(texto);
                }

                resultSet.close();
                statement.close();
                conexion.desconectar();

                return informacionVehiculos;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return informacionVehiculos; // Retorna una lista vacía si no se pudo obtener la información
    }
    
    public static List<String> obtenerNombreImagenes() {// Método de Prueba
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        List<String> name_img = new ArrayList<>();
        if (cx != null) {
            try {
                String query = "SELECT imagenes FROM Vehiculos";
                PreparedStatement statement = cx.prepareStatement(query);
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    String img = resultSet.getString("imagenes");

                    name_img.add(img);
                }

                resultSet.close();
                statement.close();
                conexion.desconectar();

                return name_img;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return name_img;
    }
    
    public static List<String> obtenerNombresMarcas() {
        List<String> nombresMarcas = new ArrayList<>();
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();

        if (cx != null) {
            try {
                String query = "SELECT Nombre FROM Marca";
                PreparedStatement statement = cx.prepareStatement(query);
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    String nombreMarca = resultSet.getString("Nombre");
                    nombresMarcas.add(nombreMarca);
                }

                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                conexion.desconectar();
            }
        }

        return nombresMarcas;
    }
    
    public static void insertarMarca(String nombreMarca, String descripcion, String nombreImagen) {
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();

        if (cx != null) {
            try {
                String query = "INSERT INTO Marca (Nombre, Descripcion, imagenes) VALUES (?, ?, ?)";
                PreparedStatement statement = cx.prepareStatement(query);

                statement.setString(1, nombreMarca);
                statement.setString(2, descripcion);
                statement.setString(3, nombreImagen);

                int filasInsertadas = statement.executeUpdate();
                if (filasInsertadas > 0) {
                    System.out.println("Nueva marca insertada exitosamente.");
                } else {
                    System.out.println("No se pudo insertar la nueva marca.");
                }

                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void insertarVehiculo(String nombre, float precio, int marca,
            int ano, String diseno, String rendimiento, String concepto, String imagen) {
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();
        
        /*nombre = "diego";
        precio = 25000;
        marca = "Marca 1";
        ano = 2023;
        diseno = "Epico";
        rendimiento = "Máximo";
        concepto = "Ninguno";
        imagen = "hola.jpg";
        */

        if (cx != null) {
            try {
            	String query = "INSERT INTO Vehiculos (Nombre, Precio, Marca, Año_Creacion, Diseno, Rendimiento, Concepto, imagenes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            	PreparedStatement statement = cx.prepareStatement(query);

            	statement.setString(1, nombre);
            	statement.setFloat(2, precio);
            	statement.setInt(3, marca);
            	statement.setInt(4, ano);
            	statement.setString(5, diseno);
            	statement.setString(6, rendimiento);
            	statement.setString(7, concepto);
            	statement.setString(8, imagen);

                int filasInsertadas = statement.executeUpdate();
                if (filasInsertadas > 0) {
                    System.out.println("Registro insertado exitosamente.");
                } else {
                    System.out.println("No se pudo insertar el registro.");
                }

                statement.close();
                conexion.desconectar();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static int buscarId_Vehiculo(String nombreMarca) {
        int idMarca = -1; // Valor predeterminado en caso de que no se encuentre la marca
        Conexion conexion = new Conexion();
        Connection cx = conexion.conectar();

        if (cx != null) {
            try {
                String query = "SELECT ID_marca FROM Marca WHERE Nombre = ?";
                PreparedStatement statement = cx.prepareStatement(query);
                statement.setString(1, nombreMarca);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    idMarca = resultSet.getInt("ID_marca");
                }

                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                conexion.desconectar();
            }
        }

        return idMarca;
    }
    

    

}
